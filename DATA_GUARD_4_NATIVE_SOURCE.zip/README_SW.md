# DATA GUARD 4.0 — Native Android Firewall (starter)

Huu ni mradi wa chanzo (source project), si APK iliyojengwa au kuthibitishwa.

## Kazi ya firewall
- Orodha ya programu zilizosakinishwa.
- Chagua programu; programu zilizochaguliwa pekee ndizo huingizwa kwenye Android VpnService.
- Pakiti zinazosomwa kutoka TUN interface hutupwa (dropped), hivyo programu hizo hazipati mtandao kupitia interface hiyo.
- Hakuna VPN server ya nje wala kutuma trafiki ya mtumiaji kwenye server.

## Tahadhari muhimu
1. Android huonyesha ombi la ruhusa ya VPN. Mtumiaji lazima akubali.
2. VPN moja tu inaweza kuwa hai kwa wakati mmoja. Kuwasha hii kunaweza kusimamisha VPN nyingine.
3. Huu ni msingi wa firewall wa majaribio. Lazima ujaribiwe kwenye simu halisi, hasa IPv4/IPv6, DNS, Android versions na programu tofauti, kabla ya kusambazwa.
4. `QUERY_ALL_PACKAGES` hutumika kuonyesha programu zote; usambazaji kupitia Google Play una masharti ya sera kuhusu ruhusa hii.
5. `targetSdk 28` imewekwa kwa starter ya majaribio/sideload. Kabla ya Play Store, target SDK na foreground-service requirements lazima zisasishwe kulingana na sera za sasa.
6. Haijajumuishwa bado: dashboard ya data usage ya kila app, battery controls, antivirus ya kweli, au cache cleaner ya mfumo. HTML/Android app haiwezi kufuta cache ya programu nyingine kiholela.

## Kujenga APK bila PC
1. Pakia ZIP hii kwenye GitHub kama repository mpya.
2. Hakikisha files ziko kwenye root ya repository.
3. Fungua tab ya Actions na uendeshe workflow `Build DATA GUARD APK`.
4. APK itapatikana kwenye sehemu ya Artifacts ya build ikikamilika.

Workflow hutumia GitHub Actions na Android SDK. Mradi huu haujajengwa wala kuthibitishwa katika kifaa hiki.
