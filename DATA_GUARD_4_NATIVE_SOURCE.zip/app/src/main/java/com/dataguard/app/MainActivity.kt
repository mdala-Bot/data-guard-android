package com.dataguard.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dg_firewall", MODE_PRIVATE) }
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private val blocked = linkedSetOf<String>()
    private val navy = Color.rgb(12, 23, 48)
    private val cyan = Color.rgb(0, 210, 230)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        blocked.addAll(prefs.getStringSet("blocked_apps", emptySet()) ?: emptySet())
        buildScreen()
        renderApps()
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 20)
            setBackgroundColor(navy)
        }
        val title = TextView(this).apply {
            text = "DATA GUARD"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "FIREWALL • ANDROID NATIVE"
            textSize = 12f
            setTextColor(cyan)
            setPadding(0, 4, 0, 18)
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(25, 43, 75))
        }
        val note = TextView(this).apply {
            text = "Chagua programu unazotaka kuzuia intaneti. Programu zilizochaguliwa pekee ndizo zitakazoelekezwa kwenye firewall hii."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 14, 0, 14)
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val apply = Button(this).apply {
            text = "WASHA / SASISHA"
            setOnClickListener { requestAndApply() }
        }
        val stop = Button(this).apply {
            text = "SIMAMISHA"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FirewallVpnService::class.java))
                status.text = "Firewall imesimamishwa."
            }
        }
        buttons.addView(apply, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))
        val scroll = ScrollView(this)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox)
        outer.addView(title)
        outer.addView(sub)
        outer.addView(status)
        outer.addView(note)
        outer.addView(buttons)
        outer.addView(TextView(this).apply {
            text = "PROGRAMU ZILIZOWEKWA KWENYE SIMU"
            textSize = 12f; setTextColor(cyan); setPadding(0, 18, 0, 8)
        })
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
        status.text = "Zilizochaguliwa kuzuiwa: ${blocked.size}"
    }

    @Suppress("DEPRECATION")
    private fun renderApps() {
        listBox.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        for (app in apps) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 8, 10, 8)
                setBackgroundColor(Color.rgb(20, 34, 63))
            }
            val icon = ImageView(this).apply {
                setImageDrawable(pm.getApplicationIcon(app))
                layoutParams = LinearLayout.LayoutParams(44, 44)
            }
            val name = TextView(this).apply {
                text = pm.getApplicationLabel(app).toString()
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(12, 0, 4, 0)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val check = CheckBox(this).apply {
                buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
                isChecked = blocked.contains(app.packageName)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) blocked.add(app.packageName) else blocked.remove(app.packageName)
                    prefs.edit().putStringSet("blocked_apps", HashSet(blocked)).apply()
                    status.text = "Zilizochaguliwa kuzuiwa: ${blocked.size}. Bonyeza WASHA / SASISHA kutumia mabadiliko."
                }
            }
            row.addView(icon); row.addView(name); row.addView(check)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 5
            listBox.addView(row, lp)
        }
        if (apps.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Hakuna programu zilizopatikana."
                setTextColor(Color.WHITE)
            })
        }
    }

    private fun requestAndApply() {
        if (blocked.isEmpty()) {
            stopService(Intent(this, FirewallVpnService::class.java))
            status.text = "Hakuna programu zilizochaguliwa. Firewall imesimamishwa."
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(prepare, VPN_REQUEST)
        } else {
            startFirewall()
        }
    }

    @Deprecated("Legacy result callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST) {
            if (resultCode == RESULT_OK) startFirewall()
            else status.text = "Ruhusa ya VPN haijatolewa. Firewall haijawashwa."
        }
    }

    private fun startFirewall() {
        val intent = Intent(this, FirewallVpnService::class.java).apply {
            action = FirewallVpnService.ACTION_UPDATE
            putStringArrayListExtra(FirewallVpnService.EXTRA_BLOCKED, ArrayList(blocked))
        }
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "Ombi la firewall limetumwa. Android itaonyesha alama/taarifa ya VPN."
    }

    companion object { private const val VPN_REQUEST = 401 }
}
