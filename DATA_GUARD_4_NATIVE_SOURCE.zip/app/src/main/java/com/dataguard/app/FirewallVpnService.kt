package com.dataguard.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local, on-device app firewall.
 * Only selected packages are included in the VPN interface; packets read from
 * that interface are intentionally discarded. No traffic is sent to a server.
 */
class FirewallVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private var reader: Thread? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopFirewall()
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val blockedApps = intent?.getStringArrayListExtra(EXTRA_BLOCKED)
        if (blockedApps != null) {
            stopTunnelOnly()
            if (blockedApps.isEmpty()) {
                stopForeground(true)
                stopSelf()
            } else {
                startTunnel(blockedApps)
            }
        } else if (vpnInterface == null) {
            stopForeground(true)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startTunnel(packages: List<String>) {
        try {
            val builder = Builder()
                .setSession("DATA GUARD Firewall")
                .setMtu(1500)
                .addAddress("10.77.0.1", 32)
                .addRoute("0.0.0.0", 0)

            // IPv6 is also routed into the filtering interface to avoid IPv6 bypass.
            builder.addAddress("fd77:da7a:1::1", 128)
                .addRoute("::", 0)

            var added = 0
            for (pkg in packages.distinct()) {
                try {
                    builder.addAllowedApplication(pkg)
                    added++
                } catch (_: Exception) {
                    // Ignore packages that were removed or are no longer visible.
                }
            }
            if (added == 0) {
                stopForeground(true)
                stopSelf()
                return
            }

            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                stopForeground(true)
                stopSelf()
                return
            }
            running.set(true)
            reader = Thread {
                val fd = vpnInterface?.fileDescriptor ?: return@Thread
                val input = FileInputStream(fd)
                val packet = ByteArray(32767)
                try {
                    while (running.get()) {
                        val count = input.read(packet)
                        if (count < 0) break
                        // Drop packet: this is the firewall block action.
                    }
                } catch (_: Exception) {
                    // Interface closed during stop/reconfigure.
                } finally {
                    try { input.close() } catch (_: Exception) {}
                }
            }.apply { name = "DataGuardPacketDropper"; isDaemon = true; start() }
        } catch (_: Exception) {
            stopTunnelOnly()
            stopForeground(true)
            stopSelf()
        }
    }

    private fun stopTunnelOnly() {
        running.set(false)
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        reader = null
    }

    private fun stopFirewall() {
        stopTunnelOnly()
        stopForeground(true)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "DATA GUARD Firewall", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_UPDATE_CURRENT
        )
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("DATA GUARD Firewall inafanya kazi")
                .setContentText("Inazuia trafiki ya programu ulizochagua kwenye simu hii.")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("DATA GUARD Firewall inafanya kazi")
                .setContentText("Inazuia trafiki ya programu ulizochagua kwenye simu hii.")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        stopFirewall()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopFirewall()
        stopSelf()
        super.onRevoke()
    }

    companion object {
        const val ACTION_UPDATE = "com.dataguard.app.UPDATE"
        const val ACTION_STOP = "com.dataguard.app.STOP"
        const val EXTRA_BLOCKED = "blocked_packages"
        private const val CHANNEL_ID = "data_guard_firewall"
        private const val NOTIFICATION_ID = 7040
    }
}
